package com.example.calculadoraimc;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import kotlin.contracts.Returns;

public class MainActivity extends AppCompatActivity {

    private EditText edNM;
    private EditText edEM;
    private EditText edIDD;
    private EditText edDCP;
    private EditText edNT1;
    private EditText edNT2;
    private Button btENVIAR;
    private Button btLIMPAR;
    private TextView tvNM;
    private TextView tvEM;
    private TextView tvIDD;
    private TextView tvDCP;
    private TextView tvNT1e2;
    private TextView tvMEDIA;
    private TextView tvAR;
    private TextView tvERRO1;
    private TextView tvERRO2;
    private TextView tvERRO3;
    private TextView tvERRO4;
    private TextView tvERRO5;
    private TextView tvERRO6;

    //String NM;
   // String EM;
   // String DCP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edNM = findViewById(R.id.edNM);
        edEM = findViewById(R.id.edEM);
        edIDD = findViewById(R.id.edIDD);
        edDCP = findViewById(R.id.edDCP);
        edNT1 = findViewById(R.id.edNT1);
        edNT2 = findViewById(R.id.edNT2);
        btENVIAR = findViewById(R.id.btENVIAR);
        btLIMPAR = findViewById(R.id.btLIMPAR);
        tvNM = findViewById(R.id.tvNM);
        tvEM = findViewById(R.id.tvEM);
        tvIDD = findViewById(R.id.tvIDD);
        tvDCP = findViewById(R.id.tvDCP);
        tvNT1e2 = findViewById(R.id.tvNT1e2);
        tvMEDIA = findViewById(R.id.tvMEDIA);
        tvAR = findViewById(R.id.tvAR);
        tvERRO1 = findViewById(R.id.tvERRO1);
        tvERRO2 = findViewById(R.id.tvERRO2);
        tvERRO3 = findViewById(R.id.tvERRO3);
        tvERRO4 = findViewById(R.id.tvERRO4);
        tvERRO5 = findViewById(R.id.tvERRO5);
        tvERRO6 = findViewById(R.id.tvERRO6);

        btENVIAR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ENVIAR();
            }
        });
        btLIMPAR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LIMPAR();
            }
        });

    }

    private double ENVIAR() {

        /*retornando texto do campo editText e
          convertendo em int (Integer.parseInt)*/
        String NM = edNM.getText().toString();
        String EM = edEM.getText().toString();
        int IDD = Integer.parseInt(edIDD.getText().toString());
        String DCP = edDCP.getText().toString();
        double NT1 = Double.parseDouble(edNT1.getText().toString());
        double NT2 = Double.parseDouble(edNT2.getText().toString());
        if (NM.equals("")) {
            tvERRO1.setText("O campo de nome está vazio");
        } else {
            tvNM.setText("Nome: " + NM);
        }
        if (EM.equals("")) {
            tvERRO2.setText("O email é invalido");
        } else {
            tvEM.setText("Email: " + EM);
        }
        if (IDD <= 0) {
            tvERRO3.setText("A idade deve ser um numero positivo");
        } else {
            tvIDD.setText("Idade: " + IDD);
        }
        if (DCP.equals("")) {
            tvERRO4.setText("O campo da disciplina está vazio");
        } else {
            tvDCP.setText("Disciplina: " + DCP);
        }
        if ((NT1 < 0) & (NT1 > 10)) {
            tvERRO5.setText("A nota deve ser de 1 a 10");
        }
        if ((NT2 < 0) & (NT2 > 10)) {
            tvERRO6.setText("A nota deve ser de 1 a 10");
        }
        tvNT1e2.setText("As notas foram 1° BI: "+ NT1 +" e 2° BI: "+ NT2);
        double media = (NT1 + NT2) / 2;
        tvMEDIA.setText("Media da nota: " + media);

        if (media < 6){
            tvAR.setText("Você foi Reprovado!!!");
        }else{
            tvAR.setText("Você foi Aprovado!!!");
        }

        return NT1;
    }
    private void LIMPAR(){
        edNM.setText("");
        edEM.setText("");
        edIDD.setText("");
        edDCP.setText("");
        edNT1.setText("");
        edNT2.setText("");

    }

}












